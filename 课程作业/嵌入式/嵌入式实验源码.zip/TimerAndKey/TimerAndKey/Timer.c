#include "stm32f10x_map.h"
#include "stdio.h"
#include "time.h"
#include "led.h"
#include "sys.h"
#include "key.h"

/***************************?????***************************/

#define GPIOB_CRL ((unsigned long int *)0x40010C00)
#define GPIOB_ODR ((unsigned long int *)0x40010C0C)
#define GPIOE_CRH ((unsigned long int *)0x40011804)
#define GPIOE_ODR ((unsigned long int *)0x4001180C)
	
u8 segTable[] = {0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x40}; 
u8 segTablePortation[] = {0xbf,0x86,0xdb,0xcf,0xe6,0xed,0xfd,0x87,0xff,0xef};

int delay_ms(int Time)
{
	unsigned short t,i,j;
	for(t=0;t<Time;t++)
		for(i=0;i<1000;i++) 
			//for(j=0;j<1000;j++)
				;
	return 0;
}

void KEY_Init(void)
{
	RCC->APB2ENR|=1<<4;
	GPIOC->CRL&=0XFFFFF000;
	GPIOC->CRL|=0X00000444;
}

u8 KEY_Scan(void)
{
	static u8 key_up=1;
	if(key_up && (KEY1==0||KEY2==0||KEY3==0))
	{
		delay_ms(10);
		key_up=0;
		if(KEY1==0)
			return 1;
		else if(KEY2==0)
			return 2;
		else if(KEY3==0)
			return 3;
	}
	else if(KEY1==1&&KEY2==1&&KEY3==1)
		key_up=1;
	return 0;
}

void EXTIX_Init(void){
	RCC->APB2ENR|=1<<4;
	GPIOC->CRL&=0XFFFFF000;
	GPIOC->CRL|=0X00000888;
	
	Ex_NVIC_Config(GPIO_C,0,FTIR);
	Ex_NVIC_Config(GPIO_C,1,FTIR);
	Ex_NVIC_Config(GPIO_C,2,FTIR);
	
	MY_NVIC_Init(2,2,EXTI0_IRQChannel,2);
	MY_NVIC_Init(2,1,EXTI1_IRQChannel,2);
	MY_NVIC_Init(2,0,EXTI2_IRQChannel,2);
}

void EXTI0_IRQHandler(void){
	delay_ms(10);
	if(KEY3==0){
		LED7=! LED7;
	}
	EXTI->PR=1<<0;
}

void LED_Init()
{
	RCC->APB2ENR|=1<<0;	      
	RCC->APB2ENR|=1<<3;       
	RCC->APB2ENR|=1<<6;	       
	
	AFIO->MAPR |= 0x02000000; 
	   	 
	GPIOB->CRL &= 0xFFFF0000;
	GPIOB->CRL |= 0x00003333; 
	GPIOB->ODR |= 0x000000FF; 
											  
	GPIOE->CRH&=0X00000000;
	GPIOE->CRH|=0X33333333;   
	GPIOE->ODR|=0x0000FF00;    	
}

void LedValue(u8 value)
{
	  LED0 = (value&0x01)?1:0;
		LED1 = (value&0x02)?1:0;
		LED2 = (value&0x04)?1:0;
		LED3 = (value&0x08)?1:0;
		LED4 = (value&0x10)?1:0;
		LED5 = (value&0x20)?1:0;
		LED6 = (value&0x40)?1:0;
		LED7 = (value&0x80)?1:0;	
}

void SetLed(u8 w, u8 value)
{
	SEL0 = w%2;
	SEL1 = w/2%2;
	SEL2 = w/4;
	LedValue(segTable[value]);
}

void PortationDisplay(u8 w, u8 value)
{
	SEL0 = w%2;
	SEL1 = w/2%2;
	SEL2 = w/4;
	LedValue( segTablePortation[value] );
}

u8 hour = 23,minute =59,second =59;

void TimerxInit(u16 arr,u16 psc)
{
	RCC->APB1ENR |= 1<<1;
	TIM3->ARR=arr;
	TIM3->PSC=psc;
	TIM3->DIER|=1<<0;
	TIM3->CR1|=0X01;
	MY_NVIC_Init(1,3,TIM3_IRQChannel,2);
}

void TIM3_IRQHandler(void)
{
	if(TIM3->SR & 0x0001)
	{
		if(second==0)
		{
			second=59;
			if(minute==0)
			{
				minute=59;
				if(hour==0)
				{
					hour=23;
				} else {
					hour--;
				}	
			} else {
				minute--;
			}
		} else {
			second--;
		}
	}
	TIM3->SR &=~(1<<0);
}

void DisplayDigitalClock(void)
{
   
	SetLed(0, hour/10);
	delay_ms(1);
	SetLed(1, hour%10);
	delay_ms(1);
	SetLed(2, 10);
	delay_ms(1);
	SetLed(3, minute/10);
	delay_ms(1);
	SetLed(4, minute%10);
	delay_ms(1);
	SetLed(5, 10);
	delay_ms(1);
	SetLed(6, second/10);
	delay_ms(1);
	SetLed(7, second%10);
	delay_ms(1);
}

int delay_s(int Time)
{
	unsigned short t,i,j;
	for(t=0;t<Time;t++)
		for(i=0;i<1000;i++) 
			for(j=0;j<1000;j++)
				;
	return 0;
}

int main()
{
	u8 t;
  Stm32_Clock_Init(9);
  delay_ms(72);
	TimerxInit( 9999,7199 ); 
  LED_Init();
	LED_SEL = 0;
	KEY_Init();
	bool flag = TRUE;
	
  while(1)
  {
    t=KEY_Scan();
    if(t)
    {
			switch(t)
			{
				case 1:
					TIM3->CR1 |= 0x02;
					flag = TRUE;
					SetLed(0, 5);
					delay_s(10);
					SetLed(0, 4);
					delay_s(10);
					SetLed(0, 3);
					delay_s(10);
					SetLed(0, 2);
					delay_s(10);
					SetLed(0, 1);
					delay_s(10);
					SetLed(0, 0);
					delay_s(10);
					break;
				case 2:
					flag = TRUE;
					hour = 23;
					minute =59;
					second =59;
					break;
				case 3: 
					flag = !flag;
					TIM3->CR1 |= 0x02;
					break;
			}
    } 
		else {
			delay_ms(1);
			if (flag) {
				TIM3->CR1 &= 0xFD;
			}
			DisplayDigitalClock();
		}
	}
	return 0;
}
