#include "led.h"
#include "sys.h"

/***************************?????***************************/
u8 segTable[] = {0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,0x40}; 
u8 segTablePortation[] = {0xbf,0x86,0xdb,0xcf,0xe6,0xed,0xfd,0x87,0xff,0xef};

void LED_Init()
{
	RCC->APB2ENR|=1<<0;	      
	RCC->APB2ENR|=1<<3;       
	RCC->APB2ENR|=1<<6;	       
	
	AFIO->MAPR |= 0x02000000; 
	   	 
	GPIOB->CRL &= 0xFFFF0000;
	GPIOB->CRL |= 0x00003333; 
	GPIOB->ODR |= 0x000000FF; 
											  
	GPIOE->CRH&=0X00000000;
	GPIOE->CRH|=0X33333333;   
	GPIOE->ODR|=0x0000FF00;    	
}



void LedValue(u8 value)
{
	  LED0 = (value&0x01)?1:0;
		LED1 = (value&0x02)?1:0;
		LED2 = (value&0x04)?1:0;
		LED3 = (value&0x08)?1:0;
		LED4 = (value&0x10)?1:0;
		LED5 = (value&0x20)?1:0;
		LED6 = (value&0x40)?1:0;
		LED7 = (value&0x80)?1:0;	
}


void SetLed(u8 w, u8 value)
{
	SEL0 = w%2;
	SEL1 = w/2%2;
	SEL2 = w/4;
	LedValue(segTable[value]);
}


void PortationDisplay(u8 w, u8 value)
{
	SEL0 = w%2;
	SEL1 = w/2%2;
	SEL2 = w/4;
	LedValue( segTablePortation[value] );
}