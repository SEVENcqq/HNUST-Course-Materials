import random
import pandas as pd
import numpy as np

# 获取数据集
def creatDataSet():
    df = pd.read_csv("data/data_KMeans.csv", encoding='utf-8')
    dataSet = df.values.tolist()
    return dataSet

def kmeans(dataSet, k, centroids):
    groups = [[] for _ in range(k)]   # 创建存放k组数据的二维列表
    print(centroids)  # 打印每次迭代的质心列表
    # 将各数据进行分组
    for data in dataSet:
        diff = np.tile(data, (k, 1)) - centroids   # 计算各点与参考点的距离
        absDist = np.sum(np.abs(diff), axis=1)  # 计算与各质点绝对值之和(axis=1表示行)的距离
        group_index = list(absDist).index(np.min(absDist))  # 所属于哪组的索引
        groups[group_index].append(data)  # 将该点添加到该组中去

    newCentroids = []   # 初始化新质心列表
    # 计算各组质心
    for group in groups:
        # 计算分组后的新的质心
        newCentroids.append(list(np.mean(group, axis=0)))  # axis=0表示列

    flag = (newCentroids == centroids)  # 判断新旧质心组是否改变

    if flag == False:  # 如果改变了递归kmeans函数，否则就返回该质心和分组
        return kmeans(dataSet, k, newCentroids)
    return newCentroids, groups

if __name__ == '__main__':
    dataSet = creatDataSet()  # 获取数据集

    k = 2  # 分组数量
    # 随机版本
    # centroids = random.sample(dataSet, k)  # 随机取k个点作为初始点

    # 课本版本
    centroids = [[1, 1], [1, 2]]

    finalCentroids, groups = kmeans(dataSet, k, centroids)
    print('----------------结果----------------')
    print(f'质心={finalCentroids}')
    for i in range(len(groups)):
        print(f'分组{i+1}={groups[i]}')
